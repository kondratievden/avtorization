<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class CheckTab
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $userId = $request->id;
        $queryTab = $request->query('tab');

        if (!$queryTab) {
            return redirect("/profile/$userId/?tab=info");
        }

        return $next($request);
    }
}
