import "./bootstrap";
import "../assets/auth/login";
import "../assets/profile/editData";
import "../assets/auth/registration";